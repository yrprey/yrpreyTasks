<?php

$mysqli = mysqli_connect('localhost', 'root', '', 'yrpreytasks');

/* Check connection before executing the SQL query */
if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $conn->connect_error);
    exit();
}

?>