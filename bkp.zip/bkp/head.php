<?php

if (isset($_GET["img"])) {
    
    echo $_GET["img"];
    
}
